// This file is no longer used. The logic has been moved to the backend.
// It is kept to prevent breaking imports if they were not all updated, but it should be considered deprecated.
export {};